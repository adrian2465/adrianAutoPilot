## Adrian Vrouwenvelder
## December 1, 2022

def readGPSDirection() -> int:
    return 300 # TODO Read GPS.

