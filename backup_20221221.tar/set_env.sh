#!/bin/bash
export PYTHONPATH=/Users/avrouwenve/Skunkworks/flask_app
